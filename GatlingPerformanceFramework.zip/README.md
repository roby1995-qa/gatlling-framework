
# Gatling Performance Testing Framework

## Overview
This framework is a basic setup for performance testing using Gatling. It includes an example simulation and is ready to extend for more advanced scenarios.

## Features
- Simple and scalable structure.
- Example simulation included.
- Uses SBT for build and dependency management.

## Prerequisites
- JDK 8 or later
- Scala 2.13
- SBT (Scala Build Tool)
- Gatling installed

## Setup Instructions

1. **Clone the Repository**:
   ```bash
   git clone <repository-url>
   cd GatlingPerformanceFramework
   ```

2. **Run Simulations**:
   ```bash
   sbt gatling:test
   ```

3. **Results**:
   Results will be available in the `target/gatling` folder after the tests run.

## Framework Structure
- **src/test/resources**: Configuration files like `logback.xml`.
- **src/test/scala/simulations**: Contains simulation scripts.
- **build.sbt**: SBT build file with dependencies.

## Contribution
Feel free to fork and submit pull requests for improvements!
