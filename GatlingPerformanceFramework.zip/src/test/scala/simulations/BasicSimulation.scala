
package simulations

import io.gatling.core.Predef._
import io.gatling.http.Predef._

class BasicSimulation extends Simulation {

  val httpProtocol = http
    .baseUrl("https://example.com") // Replace with your target URL
    .acceptHeader("application/json")
    .contentTypeHeader("application/json")

  val scn = scenario("BasicSimulation")
    .exec(http("GET Request")
      .get("/api/endpoint")) // Replace with your endpoint

  setUp(
    scn.inject(atOnceUsers(10)) // Replace with your desired user load
  ).protocols(httpProtocol)
}
